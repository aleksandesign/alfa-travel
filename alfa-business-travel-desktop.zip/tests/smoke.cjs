// Pure application tests. These do not substitute for browser/layout QA.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const listeners = {};
const elements = {};
function element(){return {innerHTML:'',textContent:'',open:false,addEventListener(){},close(){this.open=false},showModal(){this.open=true},classList:{add(){},remove(){},toggle(){}}};}
const app=elements['#app']=element();
const dialog=elements['#dialog']=element();
const content=elements['#dialog-content']=element();
elements['#toast']=element();elements['.close']=element();
let stored, storageThrows=false;
const context=vm.createContext({console,Intl,Date,JSON,crypto:{randomUUID:()=> 'test-id'},setTimeout:()=>0,clearTimeout(){},FormData:class{constructor(form){this.form=form}get(key){return this.form.data[key]||''}},localStorage:{getItem(){return stored||'[]'},setItem(k,v){if(storageThrows)throw new Error('unavailable');stored=v}},location:{hash:'#/'},window:{addEventListener(){},scrollTo(){}},document:{title:'',querySelector(s){return elements[s]||null},querySelectorAll(){return []},addEventListener(type,fn){listeners[type]=fn}}});
vm.runInContext(fs.readFileSync(path.join(root,'dist/app.js'),'utf8'),context);
const run = code => vm.runInContext(code,context);
let checks=0;function check(name,fn){fn();checks++;console.log('PASS',name)}
check('Landing has login and original image',()=>{assert.match(app.innerHTML,/href="#\/dashboard"/);assert.match(app.innerHTML,/assets\/travel-kit.png/)});
check('Dashboard includes all original trips',()=>{run("location.hash='#/dashboard'; render()");for(const name of ['Санкт-Петербург','Казань','Екатеринбург'])assert.ok(app.innerHTML.includes(name))});
check('All emitted local images exist',()=>{const html=run('landing()+dashboard()');for(const match of html.matchAll(/src="([^"]+)"/g)){const p=path.join(root,'dist',match[1]);assert.ok(fs.statSync(p).size>0,p)}});
check('No expiring Figma URLs in runtime',()=>{for(const f of ['app.js','styles.css','index.html'])assert.doesNotMatch(fs.readFileSync(path.join(root,'dist',f),'utf8'),/figma\.com\/api\/mcp\/asset/)});
check('Search finds Maria by name',()=>{run("showTrips('Мария')");assert.match(content.innerHTML,/Казань/);assert.doesNotMatch(content.innerHTML,/Екатеринбург/)});
check('Search empty state',()=>{run("showTrips('несуществующий город')");assert.match(content.innerHTML,/Ничего не найдено/)});
check('Search safely escapes user input',()=>{run(`showTrips('<img src=x onerror=alert(1)>')`);assert.doesNotMatch(content.innerHTML,/<img src=x/);assert.match(content.innerHTML,/&lt;img/)});
check('Trip details resolve the selected ID',()=>{run("handleAction('trip:ekb')");assert.match(content.innerHTML,/Дмитрий Орлов/);assert.match(content.innerHTML,/41\s600/)});
check('Other sections have working dialogs',()=>{for(const a of ['features','start','faq','client','profile','employees','documents','analytics','subscription','support']){run(`handleAction('${a}')`);assert.ok(dialog.open);assert.match(content.innerHTML,/dialog-title/)}});
function submit(data){const error=element();const form={id:'new-trip-form',data,querySelector(){return error}};listeners.submit({target:form,preventDefault(){}});return error;}
const input={city:'Тула',purpose:'Встреча',person:'Александр Букин',start:'2026-12-02',end:'2026-12-04'};
check('Rejects reversed dates',()=>{const before=run('drafts.length');const e=submit({...input,end:'2026-12-01'});assert.match(e.textContent,/не раньше/);assert.equal(run('drafts.length'),before)});
check('Rejects whitespace-only fields',()=>{const e=submit({...input,city:'  '});assert.match(e.textContent,/Укажите город/)});
check('Saves draft and includes it in trip list',()=>{submit(input);assert.equal(run('drafts.length'),1);assert.match(stored,/Тула/);assert.match(content.innerHTML,/Тула/)});
check('Draft is retained if storage is unavailable',()=>{storageThrows=true;submit({...input,city:'Омск'});assert.equal(run('drafts.length'),2);assert.match(elements['#toast'].textContent,/хранилище браузера недоступно/)});
check('Malicious draft fields are rendered as text',()=>{submit({...input,city:'<script>alert(1)</script>'});assert.doesNotMatch(content.innerHTML,/<script>/);assert.match(content.innerHTML,/&lt;script&gt;/)});
check('Reduced motion disables all animations',()=>{assert.match(fs.readFileSync(path.join(root,'dist/styles.css'),'utf8'),/prefers-reduced-motion:reduce/)});
console.log(`${checks} application checks passed; browser QA is separate.`);
